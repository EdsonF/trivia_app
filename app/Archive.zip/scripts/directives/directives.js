'use strict';


angular.module('triviaApp.directives', []);



